
import javax.swing.JLabel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class JForm extends javax.swing.JFrame {
    
    // Total cost variable declaration
    private double totalCost = 0.00;
    
    // Destination prices
    private final double NONE_PRICE = 00.00;
    private final double KRUGER_PRICE = 2500.00;
    private final double GARDEN_ROUTE_PRICE = 3200.00;
    private final double STELLENBOSCH_PRICE = 2800.00;
    private final double NAMAQUALAND_PRICE = 1900.00;
    private final double DRAKENSBERG_PRICE = 2200.00;
    
    // Transportation prices
    private final double TRAIN_PRICE = 400.00;
    private final double FLIGHT_PRICE = 1500.00;
    private final double CAR_RENTAL_PRICE = 800.00;
    
    // Accommodation prices
    private final double HOTEL_PRICE = 1500.00;
    private final double HOSTEL_PRICE = 600.00;
    private final double AIRBNB_PRICE = 900.00;
    
    // Meal plan prices
    private final double ALL_INCLUSIVE_PRICE = 1300.00;
    private final double BREAKFAST_LUNCH_PRICE = 550.00;
    private final double BREAKFAST_SUPPER_PRICE = 600.00;
    private final double LUNCH_SUPPER_PRICE = 700.00;
    private final double BREAKFAST_ONLY_PRICE = 250.00;
    private final double LUNCH_ONLY_PRICE = 350.00;
    private final double SUPPER_ONLY_PRICE = 400.00;
    private final double NO_MEALS_PRICE = 0.00;
    
    // Activity prices
    private final double ADVENTURE_ACTIVITIES_PRICE = 1200.00;
    private final double GUIDED_TOURS_PRICE = 800.00;
    private final double MUSEUM_PASSES_PRICE = 400.00;
    
    // Add a class variable to track if a date has been selected
    private boolean dateSelected = false;
    
    // Add a class variable to store selected date
    private String selectedDate = "";
    
    // Add a label for the travel date
    private JLabel travelDateLabel;
    
    // Track currently selected radio buttons to support deselection
    private javax.swing.JRadioButton lastSelectedTransportRadio = null;
    private javax.swing.JRadioButton lastSelectedMealRadio = null;
    private javax.swing.AbstractButton lastSelectedAccommodation = null;
    
    private boolean isValidEmail(String email) {
        // Simple regex pattern for email validation
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

        return email.matches(emailRegex);
    }
        
    private boolean isValidContact(String contact) {
        // Regex to ensure exactly 10 digits
        String contactRegex = "^\\d{10}$";

        return contact.matches(contactRegex);
    }
    
    /**
     * Creates new form JForm
     */
    public JForm() {
        initComponents();
        
        // Initialize button groups and other UI settings
        setupRadioGroups();
        setupAccommodationGroup();
        setupMealRadioButtons();
        
        // Set totalcosts as totalCostLabel for display
        totalCosts.setEditable(false);
        totalCosts.setText("R 0.00");

        // Add date selection listener
        jCalendar1.addPropertyChangeListener("calendar", new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                dateSelected = true;
                java.util.Date selectedDate = jCalendar1.getDate();
                java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("dd/MM/yyyy");
                String formattedDate = dateFormat.format(selectedDate);
                
                JForm.this.selectedDate = formattedDate;
                jLabel10.setText("Travel Date: " + formattedDate);
                
                updateTotalCost();
                
            }
        });
    
        // Add action listeners to all selectable options for real-time updates
        addActionListenersToOptions();
        
        // Configure submit button
        submitButton.setText("Submit");
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });
    }
    
    // Setup radio button groups with deselection capability
    private void setupRadioGroups() {
        // Transportation radio buttons
        trainRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleTransportRadioClick(trainRadio);
            }
        });

        flightRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleTransportRadioClick(flightRadio);
            }
        });

        carrentalRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleTransportRadioClick(carrentalRadio);
            }
        });
        // Group the transport radio buttons
        buttonGroup1.add(trainRadio);
        buttonGroup1.add(flightRadio);
        buttonGroup1.add(carrentalRadio);
    }

    private void handleTransportRadioClick(javax.swing.JRadioButton clickedButton) {
        if (clickedButton == lastSelectedTransportRadio) {
            // If clicking the same radio button, deselect it
            buttonGroup1.clearSelection();
            lastSelectedTransportRadio = null;
        } else {
            // Otherwise select the new one
            lastSelectedTransportRadio = clickedButton;
        }
        updateTotalCost();
    }
    
    private void setupMealRadioButtons() {
        // Add action listeners to meal radio buttons for deselection
        allinclusiveRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleMealRadioClick(allinclusiveRadio);
            }
        });

        breakfastlunchRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleMealRadioClick(breakfastlunchRadio);
            }
        });

        breakfastsupperRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleMealRadioClick(breakfastsupperRadio);
            }
        });

        lunchsupperRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleMealRadioClick(lunchsupperRadio);
            }
        });

        breakfastRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleMealRadioClick(breakfastRadio);
            }
        });

        lunchRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleMealRadioClick(lunchRadio);
            }
        });

        supperRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleMealRadioClick(supperRadio);
            }
        });

        nomealsRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleMealRadioClick(nomealsRadio);
            }
        });

        // Group the meal plan radio buttons
        buttonGroup3.add(allinclusiveRadio);
        buttonGroup3.add(breakfastlunchRadio);
        buttonGroup3.add(breakfastsupperRadio);
        buttonGroup3.add(lunchsupperRadio);
        buttonGroup3.add(breakfastRadio);
        buttonGroup3.add(lunchRadio);
        buttonGroup3.add(supperRadio);
        buttonGroup3.add(nomealsRadio);
}
    
    private void handleMealRadioClick(javax.swing.JRadioButton clickedButton) {
        if (clickedButton == lastSelectedMealRadio) {
            // If clicking the same radio button, deselect it
            buttonGroup3.clearSelection();
            lastSelectedMealRadio = null;
        } else {
            // Otherwise select the new one
            lastSelectedMealRadio = clickedButton;
        }
        updateTotalCost();
}
    
    // Setup accommodation options as mutually exclusive (checkbox style but behaving like radio buttons)
    private void setupAccommodationGroup() {
        hotelCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleAccommodationClick(hotelCheck);
            }
        });
        
        hostelCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleAccommodationClick(hostelCheck);
            }
        });
        
        airbnbCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handleAccommodationClick(airbnbCheck);
            }
        });
        
        // Add accommodation options to buttonGroup2
        buttonGroup2.add(hotelCheck);
        buttonGroup2.add(hostelCheck);
        buttonGroup2.add(airbnbCheck);
    }
    
    private void handleAccommodationClick(javax.swing.AbstractButton clickedButton) {
        if (clickedButton == lastSelectedAccommodation && clickedButton.isSelected()) {
            // Allow deselection by clicking the same button
            buttonGroup2.clearSelection();
            lastSelectedAccommodation = null;
        } else if (clickedButton.isSelected()) {
            // Update the last selected button
            lastSelectedAccommodation = clickedButton;
        }
        updateTotalCost();
    }
    
    private void addActionListenersToOptions() {
        // Add action listeners to destination combobox
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateTotalCost();
            }
        });

        // Add action listeners to activity options
        adventureactivitiesCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateTotalCost();
            }
        });

        guidedtoursCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateTotalCost();
            }
        });

        museumpassesCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateTotalCost();
            }
        });
    }
    
    private void updateTotalCost() {
        // Reset total cost
        totalCost = 0.00;
        
        // Calculate destination cost
        String destinationWithPrice = jComboBox1.getSelectedItem().toString();
        // Extract just the destination name without the price
        String destination;
        
        if (destinationWithPrice.contains("Kruger National Park")) {
        totalCost += KRUGER_PRICE;
        } else if (destinationWithPrice.contains("Garden Route")) {
            totalCost += GARDEN_ROUTE_PRICE;
        } else if (destinationWithPrice.contains("Stellenbosch")) {
            totalCost += STELLENBOSCH_PRICE;
        } else if (destinationWithPrice.contains("Namaqualand")) {
            totalCost += NAMAQUALAND_PRICE;
        } else if (destinationWithPrice.contains("Drakensberg Mountains")) {
            totalCost += DRAKENSBERG_PRICE;
        } else if (destinationWithPrice.equals("None")) {
            totalCost += NONE_PRICE;
        }
        
        // Calculate transportation cost
        if (trainRadio.isSelected()) {
            totalCost += TRAIN_PRICE;
        } else if (flightRadio.isSelected()) {
            totalCost += FLIGHT_PRICE;
        } else if (carrentalRadio.isSelected()) {
            totalCost += CAR_RENTAL_PRICE;
        }
        
        // Calculate accommodation cost
        if (hotelCheck.isSelected()) {
            totalCost += HOTEL_PRICE;
        } else if (hostelCheck.isSelected()) {
            totalCost += HOSTEL_PRICE;
        } else if (airbnbCheck.isSelected()) {
            totalCost += AIRBNB_PRICE;
        }
        
        // Calculate meal plan cost
        if (allinclusiveRadio.isSelected()) {
            totalCost += ALL_INCLUSIVE_PRICE;
        } else if (breakfastlunchRadio.isSelected()) {
            totalCost += BREAKFAST_LUNCH_PRICE;
        } else if (breakfastsupperRadio.isSelected()) {
            totalCost += BREAKFAST_SUPPER_PRICE;
        } else if (lunchsupperRadio.isSelected()) {
            totalCost += LUNCH_SUPPER_PRICE;
        } else if (breakfastRadio.isSelected()) {
            totalCost += BREAKFAST_ONLY_PRICE;
        } else if (lunchRadio.isSelected()) {
            totalCost += LUNCH_ONLY_PRICE;
        } else if (supperRadio.isSelected()) {
            totalCost += SUPPER_ONLY_PRICE;
        } else if (nomealsRadio.isSelected()) {
            totalCost += NO_MEALS_PRICE;
        }
        
        // Calculate activity costs
        if (adventureactivitiesCheck.isSelected()) {
            totalCost += ADVENTURE_ACTIVITIES_PRICE;
        }
        if (guidedtoursCheck.isSelected()) {
            totalCost += GUIDED_TOURS_PRICE;
        }
        if (museumpassesCheck.isSelected()) {
            totalCost += MUSEUM_PASSES_PRICE;
        }
        
        // Display total cost in the totalcosts textfield
        totalCosts.setText("R " + String.format("%.2f", totalCost));
    }
    
    // Reset date selection
    private void resetDate() {
        dateSelected = false;
        selectedDate = "";
        jLabel10.setText("Travel Date"); // Reset label text
        jCalendar1.setDate(new java.util.Date()); // Reset calendar to current date
    }
    
    private void calculateButtonActionPerformed(java.awt.event.ActionEvent evt) {
        // Reset total cost
        totalCost = 0.00;
        
        // Validate required fields
        if (fullNames.getText().isEmpty() || email.getText().isEmpty() || contact.getText().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please fill in all required fields.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Calculate destination cost
        String destination = jComboBox1.getSelectedItem().toString();
        switch (destination) {
            case "None":
                totalCost += NONE_PRICE;
                break;
            case "Kruger National Park":
                totalCost += KRUGER_PRICE;
                break;
            case "Garden Route":
                totalCost += GARDEN_ROUTE_PRICE;
                break;
            case "Stellenbosch":
                totalCost += STELLENBOSCH_PRICE;
                break;
            case "Namaqualand":
                totalCost += NAMAQUALAND_PRICE;
                break;
            case "Drakensberg Mountains":
                totalCost += DRAKENSBERG_PRICE;
                break;
            default:
                break;
        }
        
        // Calculate transportation cost
        if (trainRadio.isSelected()) {
            totalCost += TRAIN_PRICE;
        } else if (flightRadio.isSelected()) {
            totalCost += FLIGHT_PRICE;
        } else if (carrentalRadio.isSelected()) {
            totalCost += CAR_RENTAL_PRICE;
        }
        
        // Calculate accommodation cost
        if (hotelCheck.isSelected()) {
            totalCost += HOTEL_PRICE;
        } else if (hostelCheck.isSelected()) {
            totalCost += HOSTEL_PRICE;
        } else if (airbnbCheck.isSelected()) {
            totalCost += AIRBNB_PRICE;
        }
        
        // Calculate meal plan cost
        if (allinclusiveRadio.isSelected()) {
            totalCost += ALL_INCLUSIVE_PRICE;
        } else if (breakfastlunchRadio.isSelected()) {
            totalCost += BREAKFAST_LUNCH_PRICE;
        } else if (breakfastsupperRadio.isSelected()) {
            totalCost += BREAKFAST_SUPPER_PRICE;
        } else if (lunchsupperRadio.isSelected()) {
            totalCost += LUNCH_SUPPER_PRICE;
        } else if (breakfastRadio.isSelected()) {
            totalCost += BREAKFAST_ONLY_PRICE;
        } else if (lunchRadio.isSelected()) {
            totalCost += LUNCH_ONLY_PRICE;
        } else if (supperRadio.isSelected()) {
            totalCost += SUPPER_ONLY_PRICE;
        } else if (nomealsRadio.isSelected()) {
            totalCost += NO_MEALS_PRICE;
        }
        
        // Calculate activity costs
        if (adventureactivitiesCheck.isSelected()) {
            totalCost += ADVENTURE_ACTIVITIES_PRICE;
        }
        if (guidedtoursCheck.isSelected()) {
            totalCost += GUIDED_TOURS_PRICE;
        }
        if (museumpassesCheck.isSelected()) {
            totalCost += MUSEUM_PASSES_PRICE;
        }
        
        // Display total cost
        totalCostLabel.setText("R " + String.format("%.2f", totalCost));
        
        // Show summary dialog
        showSummary();
    }
    
    private void showSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append("Travel Package Summary\n\n");
        summary.append("Customer: ").append(fullNames.getText()).append("\n");
        summary.append("Email: ").append(email.getText()).append("\n");
        summary.append("Contact: ").append(contact.getText()).append("\n\n");

        // Format and add the selected date
        summary.append("Travel Date: ").append(selectedDate).append("\n\n");

        summary.append("Destination: ").append(jComboBox1.getSelectedItem().toString()).append("\n\n");

        summary.append("Transportation: ");
        if (trainRadio.isSelected()) {
            summary.append("Train\n");
        } else if (flightRadio.isSelected()) {
            summary.append("Flight\n");
        } else if (carrentalRadio.isSelected()) {
            summary.append("Car Rental\n");
        } else {
            summary.append("Not selected\n");
        }

        summary.append("Accommodation: ");
        if (hotelCheck.isSelected()) {
            summary.append("Hotel\n");
        } else if (hostelCheck.isSelected()) {
            summary.append("Hostel\n");
        } else if (airbnbCheck.isSelected()) {
            summary.append("Airbnb\n");
        } else {
            summary.append("Not selected\n");
        }

        summary.append("Meal Plan: ");
        if (allinclusiveRadio.isSelected()) {
            summary.append("All Inclusive\n");
        } else if (breakfastlunchRadio.isSelected()) {
            summary.append("Breakfast & Lunch\n");
        } else if (breakfastsupperRadio.isSelected()) {
            summary.append("Breakfast & Supper\n");
        } else if (lunchsupperRadio.isSelected()) {
            summary.append("Lunch & Supper\n");
        } else if (breakfastRadio.isSelected()) {
            summary.append("Breakfast Only\n");
        } else if (lunchRadio.isSelected()) {
            summary.append("Lunch Only\n");
        } else if (supperRadio.isSelected()) {
            summary.append("Supper Only\n");
        } else if (nomealsRadio.isSelected()) {
            summary.append("No Meals\n");
        } else {
            summary.append("Not selected\n");
        }

        summary.append("Activities: ");
        boolean hasActivities = false;
        if (adventureactivitiesCheck.isSelected()) {
            summary.append("Adventure Activities");
            hasActivities = true;
        }
        if (guidedtoursCheck.isSelected()) {
            if (hasActivities) {
                summary.append(", ");
            }
            summary.append("Guided Tours");
            hasActivities = true;
        }
        if (museumpassesCheck.isSelected()) {
            if (hasActivities) {
                summary.append(", ");
            }
            summary.append("Museum Passes");
            hasActivities = true;
        }
        if (!hasActivities) {
            summary.append("None");
        }
    
        summary.append("\n\nTotal Cost: R ").append(String.format("%.2f", totalCost));

        javax.swing.JOptionPane.showMessageDialog(this, summary.toString(), "Travel Package Summary", javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        fullNames = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        flightRadio = new javax.swing.JRadioButton();
        trainRadio = new javax.swing.JRadioButton();
        carrentalRadio = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        hotelCheck = new javax.swing.JCheckBox();
        hostelCheck = new javax.swing.JCheckBox();
        airbnbCheck = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        allinclusiveRadio = new javax.swing.JRadioButton();
        breakfastlunchRadio = new javax.swing.JRadioButton();
        nomealsRadio = new javax.swing.JRadioButton();
        breakfastsupperRadio = new javax.swing.JRadioButton();
        lunchsupperRadio = new javax.swing.JRadioButton();
        jLabel7 = new javax.swing.JLabel();
        guidedtoursCheck = new javax.swing.JCheckBox();
        adventureactivitiesCheck = new javax.swing.JCheckBox();
        museumpassesCheck = new javax.swing.JCheckBox();
        jLabel8 = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        contact = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        totalCostLabel = new javax.swing.JLabel();
        submitButton = new javax.swing.JButton();
        resetformButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        breakfastRadio = new javax.swing.JRadioButton();
        lunchRadio = new javax.swing.JRadioButton();
        supperRadio = new javax.swing.JRadioButton();
        totalCosts = new javax.swing.JTextField();
        jCalendar1 = new com.toedter.calendar.JCalendar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 51, 255));
        jLabel1.setText("Travel Package Calculator");

        jLabel2.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 0, 204));
        jLabel2.setText("Select Destination");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Kruger National Park R2 500", "Garden Route R3 200", "Stellenbosch R2 800", "Namaqualand R1 900", "Drakensberg Mountains R2 200", " " }));

        jLabel3.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 0, 204));
        jLabel3.setText("Full Names:");

        jLabel4.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(153, 0, 204));
        jLabel4.setText("Transportation Options");

        flightRadio.setText("Flight R1 500");
        flightRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                flightRadioActionPerformed(evt);
            }
        });

        trainRadio.setText("Train R400");
        trainRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                trainRadioActionPerformed(evt);
            }
        });

        carrentalRadio.setText("Car Rental R800");

        jLabel5.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 0, 204));
        jLabel5.setText("Accomodation Options");

        hotelCheck.setText("Hotel R1 500");
        hotelCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hotelCheckActionPerformed(evt);
            }
        });

        hostelCheck.setText("Hostel R600");

        airbnbCheck.setText("Airbnb R900");
        airbnbCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                airbnbCheckActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(153, 0, 204));
        jLabel6.setText("Meal Plan Options");

        allinclusiveRadio.setText("All Inclusive R1 300");
        allinclusiveRadio.setBorder(null);

        breakfastlunchRadio.setText("Breakfast & Lunch R550");
        breakfastlunchRadio.setBorder(null);
        breakfastlunchRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                breakfastlunchRadioActionPerformed(evt);
            }
        });

        nomealsRadio.setText("No Meals");
        nomealsRadio.setBorder(null);

        breakfastsupperRadio.setText("Breakfast & Supper R600");
        breakfastsupperRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                breakfastsupperRadioActionPerformed(evt);
            }
        });

        lunchsupperRadio.setText("Lunch & Supper R700");
        lunchsupperRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lunchsupperRadioActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(153, 0, 204));
        jLabel7.setText("Activity Options");

        guidedtoursCheck.setText("Guided Tours R800");

        adventureactivitiesCheck.setText("Adventure Activities R1 200");
        adventureactivitiesCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adventureactivitiesCheckActionPerformed(evt);
            }
        });

        museumpassesCheck.setText("Museum Passes R400");
        museumpassesCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                museumpassesCheckActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(153, 0, 204));
        jLabel8.setText("Email:");

        jLabel9.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 0, 204));
        jLabel9.setText("Phone number:");

        jLabel10.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(153, 0, 204));
        jLabel10.setText("Travel Date");

        totalCostLabel.setFont(new java.awt.Font("Lucida Fax", 1, 18)); // NOI18N
        totalCostLabel.setForeground(new java.awt.Color(153, 0, 204));
        totalCostLabel.setText("Total Costs:");

        submitButton.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        submitButton.setForeground(new java.awt.Color(153, 0, 204));
        submitButton.setText("Submit");
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });

        resetformButton.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        resetformButton.setForeground(new java.awt.Color(153, 0, 204));
        resetformButton.setText("Reset Form");
        resetformButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetformButtonActionPerformed(evt);
            }
        });

        exitButton.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        exitButton.setForeground(new java.awt.Color(153, 0, 204));
        exitButton.setText("Exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });

        breakfastRadio.setText("Breakfast Only R250");
        breakfastRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                breakfastRadioActionPerformed(evt);
            }
        });

        lunchRadio.setText("Lunch Only R350");

        supperRadio.setText("Supper Only R400");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(116, 116, 116)
                .addComponent(jLabel1)
                .addGap(0, 154, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(contact, javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel8)
                                        .addComponent(jLabel9)
                                        .addComponent(fullNames, javax.swing.GroupLayout.DEFAULT_SIZE, 292, Short.MAX_VALUE)
                                        .addComponent(email))
                                    .addComponent(jLabel4)
                                    .addComponent(trainRadio)
                                    .addComponent(flightRadio)
                                    .addComponent(carrentalRadio)
                                    .addComponent(jLabel2)))
                            .addComponent(hostelCheck)
                            .addComponent(hotelCheck)
                            .addComponent(airbnbCheck)
                            .addComponent(jLabel7)
                            .addComponent(adventureactivitiesCheck)
                            .addComponent(museumpassesCheck)
                            .addComponent(guidedtoursCheck))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(totalCostLabel)
                            .addComponent(nomealsRadio)
                            .addComponent(supperRadio)
                            .addComponent(lunchRadio)
                            .addComponent(allinclusiveRadio)
                            .addComponent(jLabel10)
                            .addComponent(jCalendar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(breakfastlunchRadio)
                            .addComponent(breakfastsupperRadio)
                            .addComponent(jLabel6)
                            .addComponent(lunchsupperRadio)
                            .addComponent(breakfastRadio)
                            .addComponent(totalCosts, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(67, 67, 67))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(submitButton)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(resetformButton)
                        .addGap(18, 18, 18)
                        .addComponent(exitButton)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1)
                .addGap(12, 12, 12)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(fullNames, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(contact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2)
                        .addGap(2, 2, 2)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(trainRadio, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(flightRadio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carrentalRadio)
                        .addGap(16, 16, 16)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(hotelCheck)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(hostelCheck)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(airbnbCheck)
                        .addGap(16, 16, 16)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(adventureactivitiesCheck)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(guidedtoursCheck))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCalendar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(allinclusiveRadio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(breakfastlunchRadio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(breakfastsupperRadio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lunchsupperRadio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(breakfastRadio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lunchRadio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(supperRadio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(nomealsRadio)
                        .addGap(18, 18, 18)
                        .addComponent(totalCostLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(totalCosts, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(museumpassesCheck)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitButton)
                    .addComponent(resetformButton)
                    .addComponent(exitButton))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void flightRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_flightRadioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_flightRadioActionPerformed

    private void hotelCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hotelCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hotelCheckActionPerformed

    private void airbnbCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_airbnbCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_airbnbCheckActionPerformed

    private void adventureactivitiesCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adventureactivitiesCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adventureactivitiesCheckActionPerformed

    private void breakfastlunchRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_breakfastlunchRadioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_breakfastlunchRadioActionPerformed

    private void trainRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_trainRadioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_trainRadioActionPerformed

    private void museumpassesCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_museumpassesCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_museumpassesCheckActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void resetformButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetformButtonActionPerformed
        // Reset personal information
        fullNames.setText("");
        email.setText("");
        contact.setText("");

        // Reset destination to first item
        jComboBox1.setSelectedIndex(0);

        // Reset accommodation selection
        buttonGroup2.clearSelection(); // Use this instead of setting each checkbox
        lastSelectedAccommodation = null;

        // Reset meal plan selection
        buttonGroup3.clearSelection(); // Use this instead of setting each radio button
        lastSelectedMealRadio = null;

        // Reset transportation selection
        buttonGroup1.clearSelection();
        lastSelectedTransportRadio = null;

        // Reset activity options
        adventureactivitiesCheck.setSelected(false);
        guidedtoursCheck.setSelected(false);
        museumpassesCheck.setSelected(false);

        // Reset total cost display
        totalCost = 0.00;
        totalCosts.setText("R 0.00");

        // Reset date selection status and button text
        selectedDate = "";
        resetDate(); // Use this method to properly reset date

        // Update the total cost display
        updateTotalCost();
        
    }//GEN-LAST:event_resetformButtonActionPerformed

    private void breakfastsupperRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_breakfastsupperRadioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_breakfastsupperRadioActionPerformed

    private void breakfastRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_breakfastRadioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_breakfastRadioActionPerformed

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
        
        // Validate required fields
        if (fullNames.getText().isEmpty() || email.getText().isEmpty() || contact.getText().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please fill in all required fields.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validate email format
        if (!isValidEmail(email.getText())) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please enter a valid email address.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate contact number format
        if (!isValidContact(contact.getText())) {
            javax.swing.JOptionPane.showMessageDialog(this, "Contact number must be exactly 10 digits.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate date selection
        if (selectedDate.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please select a travel date.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate transportation selection
        boolean transportSelected = trainRadio.isSelected() || flightRadio.isSelected() || carrentalRadio.isSelected();
        if (!transportSelected) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please select a transportation option.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        // Validate accommodation selection
        boolean accommodationSelected = hotelCheck.isSelected() || hostelCheck.isSelected() || airbnbCheck.isSelected();
        if (!accommodationSelected) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please select an accommodation option.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate meal plan selection
        boolean mealPlanSelected = allinclusiveRadio.isSelected() || breakfastlunchRadio.isSelected() || 
                                   breakfastsupperRadio.isSelected() || lunchsupperRadio.isSelected() || 
                                   breakfastRadio.isSelected() || lunchRadio.isSelected() || 
                                   supperRadio.isSelected() || nomealsRadio.isSelected();
        if (!mealPlanSelected) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please select a meal plan option.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate destination selection
        if (jComboBox1.getSelectedIndex() == 0) { // "None" is selected
            javax.swing.JOptionPane.showMessageDialog(this, "Please select a destination.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Show summary dialog
        showSummary();
        
    }//GEN-LAST:event_submitButtonActionPerformed

    private void lunchsupperRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lunchsupperRadioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lunchsupperRadioActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox adventureactivitiesCheck;
    private javax.swing.JCheckBox airbnbCheck;
    private javax.swing.JRadioButton allinclusiveRadio;
    private javax.swing.JRadioButton breakfastRadio;
    private javax.swing.JRadioButton breakfastlunchRadio;
    private javax.swing.JRadioButton breakfastsupperRadio;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JRadioButton carrentalRadio;
    private javax.swing.JTextField contact;
    private javax.swing.JTextField email;
    private javax.swing.JButton exitButton;
    private javax.swing.JRadioButton flightRadio;
    private javax.swing.JTextField fullNames;
    private javax.swing.JCheckBox guidedtoursCheck;
    private javax.swing.JCheckBox hostelCheck;
    private javax.swing.JCheckBox hotelCheck;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JRadioButton lunchRadio;
    private javax.swing.JRadioButton lunchsupperRadio;
    private javax.swing.JCheckBox museumpassesCheck;
    private javax.swing.JRadioButton nomealsRadio;
    private javax.swing.JButton resetformButton;
    private javax.swing.JButton submitButton;
    private javax.swing.JRadioButton supperRadio;
    private javax.swing.JLabel totalCostLabel;
    private javax.swing.JTextField totalCosts;
    private javax.swing.JRadioButton trainRadio;
    // End of variables declaration//GEN-END:variables
}
